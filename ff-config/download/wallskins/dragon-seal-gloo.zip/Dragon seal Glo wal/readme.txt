* How to use config file ?
1. Before you use any of Config file, please backup the “com.dts.freefire” folder inside “Android/data/” to another folder, Just copy a whole folder. So, if you have crashed or the config is broken, Just restore it back and it should be working again.

2. Then Copy or Move the downloaded config file to :
" Android > data > com.dts.freefire > files > contentcache > Compulsory > android > gameassetbundles > config > “PASTE CONFIG FILE HERE!!!” "
Congratulation! Run the game and enjoy.

Thank you!
Config FF Skin @ Google Play Store